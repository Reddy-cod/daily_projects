// Example TypeScript file, compile to JS for use in your JSPs
console.log("TypeScript is working!");