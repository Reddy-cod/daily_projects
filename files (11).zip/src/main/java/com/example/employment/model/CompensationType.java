package com.example.employment.model;

public enum CompensationType {
    SALARY, BONUS, COMMISSION, ALLOWANCE, ADJUSTMENT
}